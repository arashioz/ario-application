import { useCallback, useEffect, useState } from 'react';
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonSegment,
  IonSegmentButton,
  IonLabel,
  IonButton,
  IonInput,
  IonItem,
  IonToast,
  IonRefresher,
  IonRefresherContent,
  useIonViewWillEnter,
  RefresherEventDetail,
  IonBadge,
  IonSelect,
  IonSelectOption,
  IonChip,
  IonModal,
  IonButtons,
} from '@ionic/react';
import { wsClient, newMutationId } from '../api/ws';
import { useAuth } from '../auth/AuthContext';
import {
  formatToman,
  formatKg,
  formatDate,
  formatMoneyInput,
  parseAmount,
  INVOICE_PERIODS,
  periodRange,
  InvoicePeriod,
} from '../utils/format';
import { MoneyInput } from '../components/MoneyInput';
import { InvoiceListPanel, SaleInvRow } from '../components/InvoiceListPanel';

interface SaleInv {
  _id: string;
  invoiceNumber: string;
  customerName?: string;
  customerPhone?: string;
  customerAddress?: string;
  totalAmount: number;
  totalKg: number;
  totalProfit: number;
  discount?: number;
  status: string;
  isGolden?: boolean;
  shippingNotes?: string;
  shippingBy?: 'us' | 'courier' | 'customer' | 'none';
  shippingCost?: number;
  shippingDiscount?: number;
  shippingDescription?: string;
  driverEarned?: number;
  driverPaid?: boolean;
  date: string;
  shippedAt?: string;
  paidAt?: string;
  lastPaymentAt?: string;
  isPaid?: boolean;
  notes?: string;
  paymentMethod?: string;
  payment?: { cash?: number; card?: number; credit?: number };
  priceTier?: string;
  driverId?: string;
  items?: Array<{
    productId?: string;
    productName: string;
    qtyKg: number;
    totalPrice: number;
    unit?: 'kg' | 'package';
    qtyInput?: number;
    unitPrice?: number;
    unitPricePerKg?: number;
    discount?: number;
    kgPerPackage?: number;
  }>;
}

interface Driver {
  _id: string;
  name: string;
  lastLat?: number;
  lastLng?: number;
}

type ShippingBy = 'us' | 'courier' | 'customer' | 'none';
type SettleKind = 'paid' | 'credit';
type SettleMethod = 'cash' | 'card' | 'card_to_card';

const STATUS: Record<string, string> = {
  pending: 'منتظر تأیید',
  approved: 'آماده ارسال',
  shipped: 'ارسال شده',
  delivered: 'تحویل شد',
  cancelled: 'لغو',
};

const SHIP_BY_LABEL: Record<ShippingBy, string> = {
  us: 'ارسال با ما',
  courier: 'ارسال با پیک',
  customer: 'ارسال با مشتری',
  none: 'بدون ارسال',
};

const SETTLE_METHOD_LABEL: Record<SettleMethod, string> = {
  cash: 'نقد',
  card: 'پوز',
  card_to_card: 'کارت به کارت',
};

const Orders: React.FC = () => {
  const { isAdmin } = useAuth();
  const [tab, setTab] = useState<'pending' | 'approved' | 'shipped' | 'delivered' | 'all'>(() => {
    try {
      const v = localStorage.getItem('ario.orders.tab');
      if (v === 'pending' || v === 'approved' || v === 'shipped' || v === 'delivered' || v === 'all') {
        return v;
      }
    } catch {
      /* ignore */
    }
    return 'approved';
  });
  const [period, setPeriod] = useState<InvoicePeriod>('all');
  const [marketerPanelEnabled, setMarketerPanelEnabled] = useState(true);
  const [list, setList] = useState<SaleInv[]>([]);
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [shipNotes, setShipNotes] = useState<Record<string, string>>({});
  const [shipDriver, setShipDriver] = useState<Record<string, string>>({});
  const [shipBy, setShipBy] = useState<Record<string, ShippingBy>>({});
  const [shipCost, setShipCost] = useState<Record<string, string>>({});
  const [shipDiscount, setShipDiscount] = useState<Record<string, string>>({});
  const [shipDescription, setShipDescription] = useState<Record<string, string>>({});
  const [toast, setToast] = useState({ open: false, msg: '', color: 'success' });
  const [shipConfirm, setShipConfirm] = useState<SaleInv | null>(null);
  const [settleKind, setSettleKind] = useState<SettleKind>('paid');
  const [settleMethod, setSettleMethod] = useState<SettleMethod>('cash');
  const [shippingBusy, setShippingBusy] = useState(false);
  const [seedEdit, setSeedEdit] = useState<SaleInvRow | null>(null);

  const loadFlags = useCallback(async () => {
    try {
      const s = await wsClient.request<{ marketerPanelEnabled?: boolean }>('settings.get', {});
      setMarketerPanelEnabled(s.marketerPanelEnabled !== false);
    } catch {
      /* ignore */
    }
  }, []);

  const load = useCallback(async () => {
    const status = tab === 'all' ? undefined : tab;
    const range = periodRange(period);
    const data = await wsClient.request<SaleInv[]>('sale.list', {
      status,
      shippingQueue: true,
      ...range,
    });
    setList(data);
  }, [tab, period]);

  const loadDrivers = useCallback(async () => {
    if (!isAdmin) return;
    const data = await wsClient.request<Driver[]>('driver.list', {});
    setDrivers(data);
  }, [isAdmin]);

  useIonViewWillEnter(() => {
    void loadFlags().catch(console.warn);
    void load().catch(console.warn);
    void loadDrivers().catch(console.warn);
  });

  useEffect(() => {
    void load().catch(console.warn);
  }, [load]);

  useEffect(() => {
    if (!marketerPanelEnabled && tab === 'pending') setTab('approved');
  }, [marketerPanelEnabled, tab]);

  useEffect(() => {
    try {
      localStorage.setItem('ario.orders.tab', tab);
    } catch {
      /* ignore */
    }
  }, [tab]);

  useEffect(() => {
    const unsub = wsClient.onEvent('data_changed', (payload: unknown) => {
      const p = payload as { entity?: string };
      if (p?.entity === 'sale') void load().catch(console.warn);
    });
    return unsub;
  }, [load]);

  const openPdf = async (id: string) => {
    const res = await wsClient.request<{ html: string }>('sale.pdf', { id });
    const w = window.open('', '_blank');
    if (w) {
      w.document.write(res.html);
      w.document.close();
    }
  };

  const driverName = (id?: string) => drivers.find((d) => d._id === id)?.name;

  const resolveBy = (inv: SaleInv): ShippingBy =>
    shipBy[inv._id] || inv.shippingBy || 'none';

  const openShipConfirm = (inv: SaleInv) => {
    const hasCredit = (inv.payment?.credit || 0) > 0 || inv.paymentMethod === 'credit';
    setSettleKind(hasCredit ? 'credit' : 'paid');
    setSettleMethod('cash');
    setShipConfirm(inv);
  };

  const openOrderEdit = async (inv: SaleInv) => {
    try {
      let row: SaleInv = inv;
      if (!inv.items?.length) {
        const full = await wsClient.request<SaleInv>('sale.get', { id: inv._id });
        row = full || inv;
      }
      setSeedEdit({
        _id: row._id,
        invoiceNumber: row.invoiceNumber,
        customerId: (row as { customerId?: string }).customerId,
        customerName: row.customerName,
        customerPhone: row.customerPhone,
        customerAddress: row.customerAddress,
        totalAmount: row.totalAmount,
        totalKg: row.totalKg,
        totalProfit: row.totalProfit,
        discount: row.discount,
        status: row.status,
        isGolden: row.isGolden,
        paymentMethod: row.paymentMethod,
        payment: row.payment,
        priceTier: row.priceTier,
        date: row.date,
        notes: row.notes,
        shippingNotes: row.shippingNotes,
        shippedAt: row.shippedAt,
        paidAt: row.paidAt,
        lastPaymentAt: row.lastPaymentAt,
        isPaid: row.isPaid,
        items: row.items,
      });
    } catch (e) {
      setToast({
        open: true,
        msg: e instanceof Error ? e.message : 'فاکتور لود نشد',
        color: 'danger',
      });
    }
  };

  const confirmShip = async () => {
    if (!shipConfirm) return;
    const inv = shipConfirm;
    setShippingBusy(true);
    try {
      const by = resolveBy(inv);
      const dId = shipDriver[inv._id] || undefined;
      await wsClient.request(
        'sale.ship',
        {
          id: inv._id,
          shippingNotes: shipNotes[inv._id] || inv.shippingNotes || 'ارسال شد',
          driverId: dId || null,
          shippingBy: by,
          shippingCost:
            by === 'us' || by === 'courier'
              ? parseAmount(shipCost[inv._id] || '') || inv.shippingCost || 0
              : 0,
          shippingDiscount:
            by === 'us' || by === 'courier'
              ? parseAmount(shipDiscount[inv._id] || '') || inv.shippingDiscount || 0
              : 0,
          shippingDescription:
            by === 'us' || by === 'courier'
              ? shipDescription[inv._id] ?? inv.shippingDescription ?? ''
              : '',
          settlement: settleKind,
          settleMethod: settleKind === 'paid' ? settleMethod : undefined,
        },
        { clientMutationId: newMutationId(), queueIfOffline: true }
      );
      const settleMsg =
        settleKind === 'paid'
          ? ` · پرداخت‌شده (${SETTLE_METHOD_LABEL[settleMethod]}) — نسیه کم شد`
          : ' · نسیه باقی ماند';
      setToast({
        open: true,
        msg: (dId ? 'ارسال شده · در لیست راننده است' : 'ارسال شده · بدون راننده') + settleMsg,
        color: 'success',
      });
      setShipConfirm(null);
      await load();
    } catch (e) {
      setToast({
        open: true,
        msg: e instanceof Error ? e.message : 'خطا',
        color: 'danger',
      });
    } finally {
      setShippingBusy(false);
    }
  };

  const shippingControls = (inv: SaleInv) => {
    const by = resolveBy(inv);
    return (
      <div className="ship-controls" style={{ width: '100%', marginTop: 8 }}>
        <p className="hint convert-hint">نوع ارسال</p>
        <div className="chip-row">
          {(['us', 'courier', 'customer', 'none'] as ShippingBy[]).map((v) => (
            <IonChip
              key={v}
              className={by === v ? 'ios-chip-active' : 'ios-chip'}
              onClick={() => setShipBy({ ...shipBy, [inv._id]: v })}
            >
              {SHIP_BY_LABEL[v]}
            </IonChip>
          ))}
        </div>
        {by === 'us' && (
          <>
            <MoneyInput
              label="هزینه ارسال (تومان) — روی فاکتور مشتری"
              value={
                shipCost[inv._id] ??
                (inv.shippingCost ? formatMoneyInput(String(inv.shippingCost)) : '')
              }
              onChange={(v) => setShipCost({ ...shipCost, [inv._id]: v })}
            />
            <MoneyInput
              label="تخفیف ارسال (تومان)"
              value={
                shipDiscount[inv._id] ??
                (inv.shippingDiscount ? formatMoneyInput(String(inv.shippingDiscount)) : '')
              }
              onChange={(v) => setShipDiscount({ ...shipDiscount, [inv._id]: v })}
            />
            <IonItem className="ship-input">
              <IonInput
                placeholder="توضیح ارسال روی فاکتور…"
                value={shipDescription[inv._id] ?? inv.shippingDescription ?? ''}
                onIonInput={(e) =>
                  setShipDescription({ ...shipDescription, [inv._id]: e.detail.value || '' })
                }
              />
            </IonItem>
            <p className="hint">هزینه ارسال به مبلغ فاکتور و مانده مشتری اضافه می‌شود</p>
            <IonItem className="ship-input">
              <IonSelect
                interface="popover"
                placeholder="راننده (اختیاری)"
                value={shipDriver[inv._id] ?? inv.driverId ?? ''}
                onIonChange={(e) =>
                  setShipDriver({ ...shipDriver, [inv._id]: String(e.detail.value || '') })
                }
              >
                <IonSelectOption value="">بدون راننده — فقط ارسال شده</IonSelectOption>
                {drivers.map((d) => (
                  <IonSelectOption key={d._id} value={d._id}>
                    {d.name}
                  </IonSelectOption>
                ))}
              </IonSelect>
            </IonItem>
          </>
        )}
        {by === 'courier' && (
          <>
            <MoneyInput
              label="هزینه پیک (تومان) — روی فاکتور مشتری"
              value={
                shipCost[inv._id] ??
                (inv.shippingCost ? formatMoneyInput(String(inv.shippingCost)) : '')
              }
              onChange={(v) => setShipCost({ ...shipCost, [inv._id]: v })}
            />
            <p className="hint">هزینه پیک به مبلغ فاکتور و نسیه مشتری اضافه می‌شود</p>
          </>
        )}
        {by !== 'us' && by !== 'courier' && (
          <p className="hint">بدون راننده ثبت می‌شود و وضعیت «ارسال شده» می‌خورد</p>
        )}
        <IonItem className="ship-input">
          <IonInput
            placeholder="توضیح ارسال…"
            value={shipNotes[inv._id] || inv.shippingNotes || ''}
            onIonInput={(e) => setShipNotes({ ...shipNotes, [inv._id]: e.detail.value || '' })}
          />
        </IonItem>
      </div>
    );
  };

  return (
    <IonPage>
      <IonHeader translucent className="ios-header">
        <IonToolbar>
          <IonTitle>سفارش‌ها</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen className="page-content ios-content">
        <IonRefresher
          slot="fixed"
          onIonRefresh={async (e: CustomEvent<RefresherEventDetail>) => {
            await load();
            await loadDrivers();
            e.detail.complete();
          }}
        >
          <IonRefresherContent />
        </IonRefresher>

        <div className="ion-padding orders-page">
          <IonSegment
            value={tab}
            className="ios-segment"
            onIonChange={(e) => setTab((e.detail.value as typeof tab) || 'approved')}
          >
            <IonSegmentButton value="approved">
              <IonLabel>آماده ارسال</IonLabel>
            </IonSegmentButton>
            {marketerPanelEnabled && (
              <IonSegmentButton value="pending">
                <IonLabel>تأیید</IonLabel>
              </IonSegmentButton>
            )}
            <IonSegmentButton value="shipped">
              <IonLabel>ارسال‌شده</IonLabel>
            </IonSegmentButton>
            <IonSegmentButton value="delivered">
              <IonLabel>تحویل</IonLabel>
            </IonSegmentButton>
            <IonSegmentButton value="all">
              <IonLabel>همه</IonLabel>
            </IonSegmentButton>
          </IonSegment>

          <div className="chip-row" style={{ marginTop: 10, marginBottom: 8, flexWrap: 'wrap' }}>
            {INVOICE_PERIODS.map((p) => (
              <IonChip
                key={p.value}
                className={period === p.value ? 'ios-chip-active' : 'ios-chip'}
                onClick={() => setPeriod(p.value)}
              >
                {p.label}
              </IonChip>
            ))}
          </div>

          {list.length === 0 && <div className="empty-state">موردی نیست</div>}

          {list.map((inv) => (
            <div key={inv._id} className={`ios-glass-card ${inv.isGolden ? 'golden-card' : ''}`}>
              <div className="ios-row">
                <div>
                  <strong>
                    {inv.isGolden ? '⭐ ' : ''}
                    {inv.invoiceNumber}
                  </strong>
                  <div className="ios-caption">
                    {inv.customerName || '—'} · {inv.customerPhone || ''}
                  </div>
                </div>
                <IonBadge
                  color={
                    inv.status === 'pending'
                      ? 'warning'
                      : inv.status === 'shipped'
                        ? 'primary'
                        : inv.status === 'delivered'
                          ? 'success'
                          : 'medium'
                  }
                >
                  {STATUS[inv.status] || inv.status}
                </IonBadge>
              </div>
              <div className="stat-row">
                <span className="stat-label">مبلغ</span>
                <span className="stat-value">{formatToman(inv.totalAmount)}</span>
              </div>
              <div className="stat-row">
                <span className="stat-label">تناژ</span>
                <span className="stat-value">{formatKg(inv.totalKg)}</span>
              </div>
              <div className="stat-row">
                <span className="stat-label">تاریخ</span>
                <span className="stat-value">{formatDate(inv.date)}</span>
              </div>
              {inv.customerAddress && <p className="hint">📍 {inv.customerAddress}</p>}
              {inv.shippingBy && inv.shippingBy !== 'none' && (
                <p className="hint">
                  🚚 {SHIP_BY_LABEL[inv.shippingBy]}
                  {inv.shippingCost ? ` · ${formatToman(inv.shippingCost)}` : ''}
                </p>
              )}
              {inv.shippingNotes && <p className="hint">📝 {inv.shippingNotes}</p>}
              {inv.driverId && (
                <IonChip color="success" outline>
                  راننده: {driverName(inv.driverId) || 'ارجاع‌شده'}
                </IonChip>
              )}

              <div className="chip-row" style={{ marginTop: 8, flexWrap: 'wrap' }}>
                <IonButton size="small" fill="outline" onClick={() => void openPdf(inv._id)}>
                  PDF
                </IonButton>
                {isAdmin && (
                  <IonButton
                    size="small"
                    fill="clear"
                    color="warning"
                    onClick={() => void openOrderEdit(inv)}
                  >
                    ویرایش فاکتور
                  </IonButton>
                )}

                {isAdmin && inv.status === 'pending' && (
                  <>
                    {shippingControls(inv)}
                    <IonButton
                      size="small"
                      color="success"
                      expand="block"
                      onClick={async () => {
                        try {
                          const by = resolveBy(inv);
                          const dId = shipDriver[inv._id] || undefined;
                          await wsClient.request(
                            'sale.approve',
                            {
                              id: inv._id,
                              shippingBy: by,
                              shippingCost:
                                by === 'us' || by === 'courier'
                                  ? parseAmount(shipCost[inv._id] || '') || 0
                                  : 0,
                              shippingDiscount:
                                by === 'us' || by === 'courier'
                                  ? parseAmount(shipDiscount[inv._id] || '') || 0
                                  : 0,
                              shippingDescription:
                                by === 'us' || by === 'courier'
                                  ? shipDescription[inv._id] ?? inv.shippingDescription ?? ''
                                  : '',
                              shippingNotes: shipNotes[inv._id] || undefined,
                              driverId: dId || null,
                            },
                            { clientMutationId: newMutationId(), queueIfOffline: true }
                          );
                          setToast({
                            open: true,
                            msg: dId
                              ? 'تأیید شد و برای راننده ارسال شد'
                              : 'تأیید شد',
                            color: 'success',
                          });
                          await load();
                        } catch (e) {
                          setToast({
                            open: true,
                            msg: e instanceof Error ? e.message : 'خطا',
                            color: 'danger',
                          });
                        }
                      }}
                    >
                      تأیید
                      {resolveBy(inv) === 'us' && (parseAmount(shipCost[inv._id] || '') || 0) > 0
                        ? ' + هزینه ارسال روی فاکتور'
                        : resolveBy(inv) === 'courier' && (parseAmount(shipCost[inv._id] || '') || 0) > 0
                          ? ' + هزینه پیک روی فاکتور'
                          : ''}
                    </IonButton>
                  </>
                )}

                {isAdmin && inv.status === 'approved' && (
                  <>
                    {shippingControls(inv)}
                    <IonButton
                      size="small"
                      color="primary"
                      expand="block"
                      onClick={() => openShipConfirm(inv)}
                    >
                      ارسال شده
                    </IonButton>
                  </>
                )}

                {isAdmin && inv.status === 'shipped' && (
                  <>
                    <IonItem className="ship-input">
                      <IonSelect
                        interface="popover"
                        placeholder="راننده"
                        value={shipDriver[inv._id] ?? inv.driverId ?? ''}
                        onIonChange={(e) =>
                          setShipDriver({ ...shipDriver, [inv._id]: String(e.detail.value || '') })
                        }
                      >
                        <IonSelectOption value="">بدون راننده</IonSelectOption>
                        {drivers.map((d) => (
                          <IonSelectOption key={d._id} value={d._id}>
                            {d.name}
                          </IonSelectOption>
                        ))}
                      </IonSelect>
                    </IonItem>
                    <IonButton
                      size="small"
                      fill="outline"
                      onClick={async () => {
                        try {
                          await wsClient.request('sale.assignDriver', {
                            id: inv._id,
                            driverId: shipDriver[inv._id] || null,
                          });
                          setToast({ open: true, msg: 'راننده به‌روز شد', color: 'success' });
                          await load();
                        } catch (e) {
                          setToast({
                            open: true,
                            msg: e instanceof Error ? e.message : 'خطا',
                            color: 'danger',
                          });
                        }
                      }}
                    >
                      ذخیره راننده
                    </IonButton>
                  </>
                )}

                {isAdmin && inv.status === 'delivered' && (
                  <div style={{ width: '100%', marginTop: 8 }}>
                    {(inv.driverEarned || 0) > 0 && (
                      <p className="hint">
                        طلب راننده: {formatToman(inv.driverEarned || 0)}
                        {inv.driverPaid ? ' · پرداخت شده' : ' · منتظر پرداخت'}
                      </p>
                    )}
                    {!inv.driverPaid && (inv.driverEarned || 0) > 0 && (
                      <IonButton
                        size="small"
                        color="success"
                        expand="block"
                        onClick={async () => {
                          try {
                            const res = await wsClient.request<{ paid: number; cardNumber?: string }>(
                              'driver.payInvoice',
                              { id: inv._id },
                              { clientMutationId: newMutationId(), queueIfOffline: true }
                            );
                            setToast({
                              open: true,
                              msg: `پرداخت ${formatToman(res.paid)}${
                                res.cardNumber ? ` · کارت ${res.cardNumber}` : ''
                              }`,
                              color: 'success',
                            });
                            await load();
                          } catch (e) {
                            setToast({
                              open: true,
                              msg: e instanceof Error ? e.message : 'خطا',
                              color: 'danger',
                            });
                          }
                        }}
                      >
                        پرداخت به راننده شد
                      </IonButton>
                    )}
                    {inv.driverPaid && (
                      <IonBadge color="success">پرداخت به راننده ثبت شد</IonBadge>
                    )}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {seedEdit && (
          <InvoiceListPanel
            kind="sale"
            editOnly
            seedEdit={seedEdit}
            onSeedEditDone={() => {
              setSeedEdit(null);
              void load();
            }}
            onToast={(msg, color) => setToast({ open: true, msg, color: color || 'success' })}
          />
        )}

        <IonModal isOpen={!!shipConfirm} onDidDismiss={() => setShipConfirm(null)}>
          <IonHeader>
            <IonToolbar>
              <IonTitle>پرداخت هنگام ارسال</IonTitle>
              <IonButtons slot="end">
                <IonButton onClick={() => setShipConfirm(null)}>بستن</IonButton>
              </IonButtons>
            </IonToolbar>
          </IonHeader>
          <IonContent className="ion-padding">
            {shipConfirm && (
              <>
                <p>
                  فاکتور <b>{shipConfirm.invoiceNumber}</b>
                  {(shipConfirm.payment?.credit || 0) > 0
                    ? ` · نسیه فعلی ${formatToman(shipConfirm.payment?.credit || 0)}`
                    : ''}
                </p>
                <p className="hint">این فاکتور پرداخت شده بود یا نسیه؟</p>
                <div className="chip-row">
                  <IonChip
                    className={settleKind === 'paid' ? 'ios-chip-active' : 'ios-chip'}
                    onClick={() => setSettleKind('paid')}
                  >
                    پرداخت شده
                  </IonChip>
                  <IonChip
                    className={settleKind === 'credit' ? 'ios-chip-active' : 'ios-chip'}
                    onClick={() => setSettleKind('credit')}
                  >
                    نسیه
                  </IonChip>
                </div>
                {settleKind === 'paid' && (
                  <>
                    <p className="hint" style={{ marginTop: 12 }}>
                      روش دریافت (نسیه کم می‌شود)
                    </p>
                    <div className="chip-row">
                      {(['cash', 'card', 'card_to_card'] as SettleMethod[]).map((m) => (
                        <IonChip
                          key={m}
                          className={settleMethod === m ? 'ios-chip-active' : 'ios-chip'}
                          onClick={() => setSettleMethod(m)}
                        >
                          {SETTLE_METHOD_LABEL[m]}
                        </IonChip>
                      ))}
                    </div>
                  </>
                )}
                {settleKind === 'credit' && (
                  <p className="hint" style={{ marginTop: 12 }}>
                    نسیه روی فاکتور می‌ماند و در بدهکاران ثبت می‌شود.
                  </p>
                )}
                <IonButton
                  expand="block"
                  className="ios-primary-btn ion-margin-top"
                  disabled={shippingBusy}
                  onClick={() => void confirmShip()}
                >
                  {shippingBusy ? '…' : 'تأیید ارسال'}
                </IonButton>
              </>
            )}
          </IonContent>
        </IonModal>

        <IonToast
          isOpen={toast.open}
          message={toast.msg}
          color={toast.color}
          duration={2200}
          onDidDismiss={() => setToast((t) => ({ ...t, open: false }))}
          position="top"
        />
      </IonContent>
    </IonPage>
  );
};

export default Orders;
